# CMPS 260 - Linux Assignment

## Problem 0: Enviroment Setup

### what does 'pwd do?
The 'pwd' command prints the full path of the current working directory. It shows where the user is
currently located in the filesystem.

### What does 'whoami' do?
The 'whoami' command displays the username of the user who is currently logged in and executing in the
shell

### Explain why the two commands in step 1 behaves differently.
The semicolon (';") is a shell operator that sepreates commands, causing them to run sequentially 
regardless of success or failure. When the semicolon is place inside quotes, it loses its special
meaning and is treated as a literal character. As a result, 'ls ";" date' attempts to list files named 
';' and 'date', which do not exist.

## Step 7: Explaination of step 6
In step 6, the 'ls -R data' command recursively lists all directories and files the 'data' directory. 
The '-R' option causes 'ls' to display the entire directory tree, including subdirectories. The output 
is appended to  'outputs/problem1_lecture2.txt' using '>>', whcih preserves any existing contents in 
the file while adding the new output.

## step 22: umask behavior
In steps 17-21, the 'umask' value was checked and then changed before creating new files. The file 
created before changing the umask inherited the default permissions, while the file created after 
changing the umask had more restrictive permissions. This demonstrates how 'umask' affects the default 
permissions assigned to newly created files.

## Step 25: Hard links vs Symbolic links
In step 23, a regular file was created along with a hard link and a symbolic link pointing to it. The
hard link and the orignial file shared the same inode number, meaning they both referenced the same 
data on disk. The symbolic link, however, pointed to the file by pathname rahter than inode.

In step 24, the original file was deleted, After deletion, the hard link continued to work still 
allowed access to the file contents because the data remained on disk as long as at least one hard link
existed. The symbolic link became broken because it referenced a pathname that no existed.

## Step 31: diff vs cmp
In step 29-30, two similar text files were created with a small difference in one line. The 'diff' 
command compared the files line by line and displayed the exact lines that differed. The 'cmp' command compared the files byte and reported the first position where the files differed. This 
demonstrated that 'diff' is more human-readable, while 'cmp' is more low-level and precise.
